clc
%SNR 
%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%
%%%%Do we add SNR via Eb/No (Digital) or SNR (Analog)
ebnodbvec = [2, 6, 12, 18, 24]; %SNR List (not used now)
SNRType = 'Analog';  %'Digital', 'Analog'
SNRValdB  =  40;  %Signal to Noise in dB
SigDataType = 'Complex'; %Most of the time assume complex data, affect AWGN addition
ChannType  = 'FadingPNoise'; %Fading, FadingPNoise, AWGN 
PhyChan = 'Data'; %'Data', 'Synch', 'Security':  Security is not used
%%%Let Data Channel bins be a multiple of 4 for MIMO
NumBins0 = 12; %Number of occupied bins for Data channel
NumBins = 4*ceil(NumBins0/4);  %Data Channel Bins 
NFFT = 64;  % NFFT >= NumBins
ModulationType = 'QPSK';  %per Bin
NumBitsSymb = 2; %per Bin %Random Bits
NumSymbols0 = 6; %%%%Length and Type of Symbol Stream
%%%%%%%%%%%%Symbol Pattern
Synch_Data = [1,1];
%0:  Synch Symbol,  1:  Data Symbol
Symb0   = [zeros(1,Synch_Data(1)), ones(1,Synch_Data(2))];
LPatt = round(NumSymbols0/sum(Synch_Data));
NumSymbols=sum(Synch_Data)*LPatt;
SymbPat = repmat(Symb0, 1, LPatt);
%SymbPat = repmat([0,1],1, round(NumSymbols/2));
xindat = randi([0 1],NumSymbols*NumBins*NumBitsSymb,1);  %Information Source of Data
%%Data Channel Binsused
BinsUsed = [-NumBins/2: -1, 1: NumBins/2];    %approximate -2MHz to 2MHz for NumBins=12
fs = 20e6; %sampling frequency corresponds to 802.11
Ts=1/fs;    %sampling period
DeltaF= fs/NFFT;  %bin spacing in frequency
LenCP = NFFT/4;  %cyclic prefix
%%%%%%%%%%%%%%MIMO OFDM Symbol Parameters
NumAntTxRx = 1; 
MIMOMethod = 'STCode';  %Space Time Code (only current MIMO Mode)
%Define a Synch Object
Msynch=NFFT-2;   %number of bins in the Synch 
NumSynchBins = Msynch;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%OFDM Symbol constructor:  Define the Basic Parameters for the OFDM Symbol
ODat = OFDMExamp1(LenCP, NumBins, ModulationType, NFFT, DeltaF);  %constructor for ODat

%Multi antenna constructor
SysChan = MultiAntennaSys(ODat, NumAntTxRx,MIMOMethod, BinsUsed, NumSymbols);

%Method in the MultiAntennSys class for Synch Signal Contructor
Caz1 = SynchSig(SysChan.OFDMob.LenCP, NumSynchBins, ...
    NumAntTxRx, SysChan.Nfft, Synch_Data);

%Method in MultiAntennaSys class for binary to complex mapping:  
%Using the MultiAntennaSys Map bit streams to field of complex 
    MultAntBinaryMap(SysChan, xindat, NumAntTxRx, ...
        MIMOMethod, SymbPat, Caz1.ZC0, Caz1.UsedBinIndex, ...
        Caz1.M, Caz1.synch_data, Caz1.SynchState)

%Method in MultiAntennaSys class  
%complex layer to multi-Antenna mapping
MultiAntSymbGen(SysChan, NumSymbols); 

%Method in MultiAntennaSys class  
%frequency to time symbols conversion
%Also, generate the multiple fading channels for communication
%send the time data through the fading channel
MIMOChanGen(SysChan, ChannType);

%Method in MultiAntennaSys class  
%Add AWGN Noise at the Receiver to the fading channel
%Generate the Rx channels
AdditiveNoise(SysChan, SNRType, SNRValdB, ChannType, SigDataType)


%RxBasebandSys Constructor for the Received Signal
%Transfer Tx Parameters to Rx
RxSys=RxBasebandSys(SysChan, Caz1);

%Method in RxBasebandSys class; estimate the delay, channel, and synch  
ParamEstAndSynch(RxSys);

RecoveredSynch=RxSys.EstSynchFreq(1:RxSys.CorObs,:);
ChannelEst = RxSys.EstChanImpulse(1:RxSys.CorObs,1:LenCP);
TimingSynch = RxSys.TimSynchRef(1:RxSys.CorObs,:);
%Create a plot script externally
%Time domain plot

%Method in RxBasebandSys class; estimate data channel
RxDataChDemod(RxSys);

%Display the Data channel Scatter Plot
SymbInd = 1;
figure(1)
plot(real(RxSys.EstDataFreq(SymbInd,:)), imag(RxSys.EstDataFreq(SymbInd,:)), '.')
xlabel('In-Phase Axis, I')
ylabel('Quadrature Axis, Q');
title('Scatter Plot of Data Channel');


%%%%%%%%%%%%%%%%%%%%%%%%%Plot the IF Signal
AntNum =1;

%%%%%%%%%%
% Your Task: Create the receive signal by convolving the time domain channel
% with the channels in the SysChan object
% Create a method to recoveres the binary data using alamout demod
%%%%%%%%%%
%t1_long  = SysChan.BuffDatTimeTx(AntNum,:) ;  %extract the time domain signal from the object ODat
AntNum =1 ;
t1_long  = SysChan.BuffDatTimeRx(AntNum,:);

figure(2)
subplot(2, 1, 1);
plot(real(t1_long));
grid on
xlabel('Time');
ylabel('Real');
subplot(2, 1, 2);
plot(imag(t1_long));
grid on
xlabel('Time');
ylabel('Imaginary');

%Frequency Domain plot of basband signal
FigParm.Title = 'Frequency Domain Plot';
FigParm.xaxis = 'Frequency in Hz';
FigParm.yaxis = 'Amplitude in dB';
FigPlotNum=3;
GoodPlotFreq(SysChan, t1_long, fs, FigPlotNum, FigParm) 

%RF Modulate the baseband signal to an RF carrier frequency (low IF)
fc=2.5e6;
%t2_long= t1_long.*exp(1i*2*pi*fc*(0:NFFT+LenCP-1).'*Ts);  
t2_long = real(reshape(t1_long,1,numel(t1_long))) .* cos(2*pi*fc*(0:(length(t1_long)-1)*Ts)) - ...
                imag(reshape(t1_long,1,numel(t1_long))) .* sin(2*pi*fc*(0:(length(t1_long)-1)*Ts));
FigParm.Title = 'IF/RF Frequency Domain Plot';
FigParm.xaxis = 'Frequency in Hz';
FigParm.yaxis = 'Amplitude in dB';
FigPlotNum=4;
%Frequency Domain plot of the IF signal 
GoodPlotFreq(SysChan, t2_long, fs, FigPlotNum, FigParm) 