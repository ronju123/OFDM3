function ParamEstAndSynch(obj)

LoopZ = round(obj.Nfft/obj.CP);
CorObs = zeros(1,LoopZ);

DelK=16;
for m =1:obj.MIMOAnt
for P=1:LoopZ
%%%%%%%%%%Select the TimeDomain Buffer of Data%%%%%%%%%%%%    
obj.RxBufferTim = obj.RxBufferTimLong(m,((P-1)*obj.CP+1+DelK:(P-1)*obj.CP+obj.Nfft+DelK));
Tmp1Vec = fft(obj.RxBufferTim, obj.Nfft); %Pos index
%%%%%%%%If Data Use Freq Data%%%%
FreqDat =  Tmp1Vec(obj.BinsUsed);  %pos Index
%%%%%If Synch Use Synch Data%%%%%%%
SynchDat = Tmp1Vec(obj.SynchBinsUsed);

%Actual Frequency Channel
ChanFreq = reshape(obj.MIMOChanFreq(obj.SynchBinsUsed), 1,numel(obj.SynchBinsUsed));

%Reformulated Synch Data
EstSynchDat=obj.SynchRef.*reshape(ChanFreq,1,numel(ChanFreq));

%Delay Estimation
obj.DelMat=obj.SynchRef*(diag(SynchDat')*exp(-1i*2*(pi/obj.Nfft)* (obj.SynchBinsUsed-1).'*(0:obj.CP)));
[dmax, dmaxind0] = max(real(obj.DelMat));
dmaxind = dmaxind0-1;
%dmaxind=0;
%%%%%Recovered Data with Delay Removed
DataRecov = diag(SynchDat)*exp(1i*2*(pi/obj.Nfft)*(obj.SynchBinsUsed-1).'*(dmaxind));

%%%%Channel Estimate
Hest1=zeros(obj.Nfft,1);
TmpV1 = DataRecov./(obj.SynchRef.'+(1/obj.SNR));
Hest=TmpV1; %negative inices first
Hest1(obj.SynchBinsUsed)=Hest; %positive indices first

%Impulse Response of Channel
HestTim = ifft(Hest1, obj.Nfft);

%Recovered Data
DataRecov2 = DataRecov.*conj(Hest)./((conj(Hest).*Hest)+(1/obj.SNR)); %Neg first

plot((0:obj.CP),real(obj.DelMat));
dbg77=1;
end
end


end

