function ParamEstAndSynch(obj)

LoopZ = round(size(obj.RxBufferTimLong,2)/obj.CP);

obj.StrideVal = 13;
obj.StartSamp = 17;
MM = obj.SynchSys;
for m =1:obj.MIMOAnt
    for P=1:LoopZ
        %%%%%%%%%%Select the TimeDomain Buffer of Data%%%%%%%%%%%%
        if (P-1)*obj.StrideVal+obj.Nfft+obj.StartSamp < size(obj.RxBufferTimLong,2)
            obj.RxBufferTim = obj.RxBufferTimLong(m,((P-1)*obj.StrideVal+obj.StartSamp:(P-1)*obj.StrideVal+obj.Nfft+obj.StartSamp-1));
            
            %%%%%%%%If Data Use Freq Data%%%%
            %FreqDat =  Tmp1Vec(obj.BinsUsed);  %pos Index
            Tmp1Vec = fft(obj.RxBufferTim, obj.Nfft); %Pos index
            
            %%%%%If Synch Use Synch Data%%%%%%%
            SynchDat0 = Tmp1Vec(obj.SynchBinsUsed);
            Pest = sum(SynchDat0.*conj(SynchDat0))/length(SynchDat0);
            SynchDat = SynchDat0/sqrt(Pest);
            
            %%%%Genie: Actual Frequency Channel
            ChanFreq = reshape(obj.MIMOChanFreq(obj.SynchBinsUsed), 1,numel(obj.SynchBinsUsed));
            
            %Genie Reformulated Synch Data
            EstSynchDat=obj.SynchRef.*reshape(ChanFreq,1,numel(ChanFreq));
            
            %Delay Estimation
            obj.DelMat=conj(obj.SynchRef)*(diag(SynchDat)*exp(1i*2*(pi/obj.Nfft)* (obj.SynchBinsUsed-1).'*(0:obj.CP)));
            [dmax, dmaxind0] = max(real(obj.DelMat));
            dmaxind = dmaxind0-1;  %Matlab
            %obj.EstimTimDel = dmaxind;
            
            if dmax > length(SynchDat)/3
                obj.CorObs = obj.CorObs+1;
                %obj.TimSynchRef(obj.CorObs,1)=(P-1)*obj.CP+1+obj.StartSamp;
                %obj.TimSynchRef(obj.CorObs,1)=(P-1)*obj.StrideVal+obj.Nfft+obj.StartSamp;
                obj.TimSynchRef(obj.CorObs,1)=(P-1)*obj.StrideVal+obj.StartSamp;
                obj.TimSynchRef(obj.CorObs,2)= dmaxind;
                
                %%%%%Recovered Data with Delay Removed
                DataRecov = diag(SynchDat)*exp(1i*2*(pi/obj.Nfft)*(obj.SynchBinsUsed-1).'*(dmaxind));
                
                %%%%Channel Estimate
                Hest1=zeros(obj.Nfft,1);
                %TmpV1 = DataRecov./(obj.SynchRef.'+(1/obj.SNR));
                %TmpV1 = DataRecov.*(obj.SynchRef')./((obj.SynchRef.*conj(obj.SynchRef)).'+ 1/obj.SNR);
                TmpV1 = DataRecov.*(obj.SynchRef')./(1 + 1/obj.SNR);

                Hest=TmpV1; %negative inices first
                Hest1(obj.SynchBinsUsed)=Hest; %positive indices first
                obj.EstChanFreqP(obj.CorObs, 1:length(Hest1))=Hest1;
                obj.EstChanFreqN(obj.CorObs, 1:length(Hest))=Hest;
                
                %Impulse Response of Channel
                HestTim = ifft(Hest1, obj.Nfft);
                obj.EstChanImpulse(obj.CorObs,1:length(HestTim))=HestTim;
                
                %Recovered Data
                obj.EstSynchFreq(obj.CorObs,1:length(obj.SynchBinsUsed)) = DataRecov.*conj(Hest)./((conj(Hest).*Hest)+(1/obj.SNR)); %Neg first
                
                plot((0:obj.CP),real(obj.DelMat));
            end
            dbg77=1;
        end
    end
    dbg77=1;
end
dbg77=1;

end
