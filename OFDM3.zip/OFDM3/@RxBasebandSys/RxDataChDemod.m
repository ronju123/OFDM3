function RxDataChDemod(obj)

LoopZ = round(size(obj.RxBufferTimLong,2)/obj.CP);


for m =1:obj.MIMOAnt
    for P=1:obj.CorObs
        %%%%%%%%%%Select the TimeDomain Buffer of Data%%%%%%%%%%%%
        if  sum(obj.TimSynchRef(P,:))+obj.Nfft + obj.RxBLen -1 < size(obj.RxBufferTimLong,2)
            %DataPtr = sum(obj.TimSynchRef(P,:))+obj.RxBLen;
            DataPtr = obj.TimSynchRef(P,1)+obj.RxBLen;
            obj.RxBufferTim = obj.RxBufferTimLong(m,DataPtr:DataPtr+obj.Nfft-1);

            %%%%%%%%If Data Use Freq Data%%%%
            %FreqDat =  Tmp1Vec(obj.BinsUsed);  %pos Index
            Tmp1Vec = fft(obj.RxBufferTim, obj.Nfft); %Pos index
            
            %%%%%If Synch Use Synch Data%%%%%%%
            FreqDat0 = Tmp1Vec(obj.BinsUsed);
            Pest = sum(FreqDat0.*conj(FreqDat0))/length(FreqDat0);
            DataRecov0 = FreqDat0/sqrt(Pest);
            
            %%%%Genie: Actual Frequency Channel
            Hest =obj.EstChanFreqP(P, obj.BinsUsed);    
                %Recovered Data
           DataRecov = diag(DataRecov0)*exp(1i*2*(pi/obj.Nfft)*(obj.BinsUsed-1).'*(obj.TimSynchRef(P,2)));
           obj.EstDataFreq(P,1:length(obj.BinsUsed)) = (DataRecov.').*(conj(Hest)./((conj(Hest).*Hest)+(1/obj.SNR)));
           %Neg first
           dbg77=1;   
        end
            dbg77=1;
        end
    end
    dbg77=1;
end

