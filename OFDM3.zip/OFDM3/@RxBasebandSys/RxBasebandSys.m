classdef RxBasebandSys < handle
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
      MIMOAnt=[];
      MIMOChanFreq=[];
      AntSys=[];
      SynchSys=[];
      RxBufferFreq=zeros(1,16);
      RxBufferTim =zeros(1,16);
      RxBufferTimLong = zeros(1,16);
      RxBLen=16;
      CP =[];
      Nfft  =[];
      Lh =[];
      Ptri=(8:71);
      Ptro=(17:80);
      TDel0=[];
      FDel0=[];
      SynchRef=[];
      SynchBinsUsed =[];
      BinsUsed = [];
      DelMat=0;
      SNR=[];
      EstChanFreqP=[];
      EstChanFreqN=[];
      EstChanTim=[];
      EstDataFreq=[];
      EstSynchFreq=[];
      TimSynchRef =[];
      EstChanImpulse =[];
      CorObs=0;
      StrideVal = 16;
      StartSamp = 16;
    end
    
    methods
        function obj=RxBasebandSys(varargin)
            dbg77=1;
            for k=1:nargin
                switch k
                    case 1
                        obj.AntSys=varargin{1};
                        obj.MIMOAnt = obj.AntSys.MIMOAnt;
                        obj.Nfft = obj.AntSys.Nfft;
                        obj.CP = obj.AntSys.OFDMob.LenCP;
                        obj.RxBLen = obj.CP + obj.Nfft;
                        obj.RxBufferTimLong=obj.AntSys.BuffDatTimeRx(:,:);
                        obj.BinsUsed=obj.AntSys.UsedBinIndex;
                        obj.SNR = obj.AntSys.SNR;
                        obj.MIMOChanFreq=obj.AntSys.ChannelMatFreq;
                    case 2
                        obj.SynchSys=varargin{2};
                        obj.SynchRef=obj.SynchSys.ZC0;
                        obj.SynchBinsUsed = obj.SynchSys.UsedBinIndex;
                        obj.Ptro=(obj.CP:obj.CP+obj.Nfft-1);
                        obj.Ptri=obj.Ptro-round(obj.CP/2);
                        obj.RxBufferTim  = obj.RxBufferTimLong(:,obj.Ptri);
                        obj.TimSynchRef = ones(size(obj.RxBufferTimLong,1),2);
                        %obj.RxBufferFreq = fft(obj.RxBufferTim,obj.N);
                        %obj.DelMat=exp(1i*2*(pi/obj.Nfft)*(obj.CP:-1:0).'*(obj.SynchBinsUsed-1))*obj.SynchRef';
                        LMAX=100;
                        obj.EstChanFreqP=zeros(LMAX,obj.Nfft);
                        obj.EstChanFreqN=zeros(LMAX,length(obj.SynchBinsUsed));
                        obj.EstChanTim=zeros(LMAX,2);
                        obj.EstSynchFreq=zeros(LMAX,length(obj.SynchBinsUsed));
                        obj.EstDataFreq=zeros(LMAX,length(obj.BinsUsed));
                        obj.TimSynchRef =zeros(LMAX,2);
                        obj.EstChanImpulse  =zeros(LMAX, obj.CP);
                        dbg77=1;
                end
            end
            %%%%%%%%%%%%%%  
            
        end
            

    end

end
            
       
