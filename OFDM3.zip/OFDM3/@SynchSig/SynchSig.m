classdef SynchSig < handle
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        LenCP=16;  % Length Cyclic Prefix
        NumUsedBins=64; % Number of Bins
        BuffDat = [];  % Buffer of Frequency Data
        BuffDatTime = []; % Buffer of Time Data
        Nfft  = [];
        BinSpacing = 15e3; %LTE 15e3;  Wifi  312.5KHz
        NumBits = 1; 
        UsedBinIndex =[];
        UsedBinIndexPos = [];
        epsvar=1e-30;
        p=23;
        nvar=0.001;
        ALi=[];  % range low
        AHi=[];       % range high
        AL=[];
        AH=[];
        ZC0 = [];
        ZC1 = [];
        rangerL=[];
        rangerH=[];
        NumAnt=[];
        M=[];
        synch_data = [1,1];
        SynchState = 0;
        %%%%%%%%%%%%%%%%%%%%%%
    end
    
    methods
        function obj=SynchSig(varargin)
            
            for k=1:nargin
                switch k
                    case 1
                        obj.LenCP=varargin{1};
                    case 2
                        
                        obj.NumUsedBins=varargin{2};
                    case 3
                        obj.NumAnt=varargin{3};
                    case 4
                        obj.Nfft=varargin{4};
                       Msynch = obj.NumUsedBins/2;
                        obj.UsedBinIndex=...
                            rem(obj.Nfft+[-Msynch:-1,1: Msynch], obj.Nfft)+1;
                    case 5
                       obj.synch_data=varargin{5};
                end
            end
            %%%%%%%%%%%%%%  
            obj.M=[obj.synch_data(1), obj.NumUsedBins];
            MM = prod(obj.M);
            Ts=1/(obj.Nfft*obj.BinSpacing);
            obj.ALi=floor(2e-6/Ts);  % range low
            obj.AHi=ceil(25e-6/Ts);       % range high
            obj.AL=round(obj.ALi*Ts);
            obj.AH=round(obj.AHi*Ts);

            
            %%%%%%%%%%%%%
            obj.BuffDat = zeros(obj.NumUsedBins,1);
            %obj.UsedBinIndex = 1+rem([-obj.NumUsedBins/2:-1,1:obj.NumUsedBins/2]+obj.Nfft, obj.Nfft);
            obj.BuffDat = zeros(obj.Nfft,1);
            %rind = randi([obj.ALi obj.AHi],1,1);
            %r=Ts*rind;
            %obj.rangerL=ceil((restg-obj.AL)/Ts);
            %obj.rangerH=ceil((obj.AH-restg)/Ts);
            
            switch rem(prod(obj.M),2) %Zadoff Chu CAZAC sequence
                case 0
                    obj.ZC0=exp(-1i*(2*pi/MM)*obj.p*((0:MM-1).^2)/2);
                case 1
                    obj.ZC0=exp(-1i*(2*pi/MM)*obj.p*((0:MM-1).*(1:MM))/2);
            end
            obj.ZC1=zeros(obj.synch_data(1),obj.Nfft);
            for LK = 1:obj.synch_data(1)
              obj.ZC1(LK, obj.UsedBinIndex)=obj.ZC0((LK-1)*obj.M(2)+1:LK*obj.M(2));
            end
            dbg77=1;
        end
            

    end

end
            
       
