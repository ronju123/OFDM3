function [nvar]=ebnodbtonoisevar(sigpow, ebnodb, samppersymb, bitspersymb, sigtype)

switch sigtype
case 'real'
    nvar = (1/bitspersymb)*samppersymb*sigpow*10^(-ebnodb/10);
case 'complex'
    nvar = (1/bitspersymb)*samppersymb*sigpow*10^(-ebnodb/10)/2;     
end





