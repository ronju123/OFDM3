classdef MultiAntennaSys < handle
    % MultiAntenna System Class
    % Handles most MIMO Modes    
    properties
        MIMOAnt=1;  % 1Ant, 2Ant, 4Ant
        MIMOType = 'STCode';  %'STCode', 'SPMult', 'BeamForm', 'MassiveM
        NumUsedBins=64; % Number of Bins
        BuffDatTx = [];  % Buffer of Frequency Data
        BuffDatRx = [];  % Buffer of Frequency Data
        ChannelMatTim = [];
        ChannelMatFreq = [];
        BuffDatTimeTx = []; % Buffer of Time Data
        BuffDatTimeRx = []; % Buffer of Time Data
        Nfft  = [];
        UsedBinIndex =[];
        OFDMob = [];
        MaxImpulse = [];
        SNRVdB = 8;
        SNR = [];
        Synch_Data = [0,1];
        SynchState = 0;
        M=[];
    end

    methods
        function obj=MultiAntennaSys(varargin)
            for k=1:nargin
                switch k
                    case 1
                        obj.OFDMob=varargin{1};
                    case 2
                        obj.MIMOAnt=varargin{2};
                    case 3
                        obj.MIMOType=varargin{3};
                    case 4
                       obj.Nfft = obj.OFDMob.Nfft;
                       Tmpcompute=rem(varargin{4}+obj.Nfft, obj.Nfft)+1;
                       obj.UsedBinIndex=Tmpcompute;
                    case 5
                        NumSymbols=varargin{5};
                end
            end
            %%%%%Constructor Here%%%%%
            obj.SNR=10^(obj.SNRVdB/10);
            obj.NumUsedBins = obj.OFDMob.NumUsedBins;
      
            obj.MaxImpulse = obj.OFDMob.LenCP; 

            obj.BuffDatTx = zeros(obj.MIMOAnt,obj.Nfft*NumSymbols);  % Buffer of Frequency Data
            obj.BuffDatRx = zeros(obj.MIMOAnt,obj.Nfft*NumSymbols);  % Buffer of Frequency Data
        
            obj.ChannelMatTim = zeros(obj.MIMOAnt,obj.MIMOAnt, obj.MaxImpulse); 
            obj.ChannelMatFreq = zeros(obj.MIMOAnt,obj.MIMOAnt,obj.Nfft); 
            
            obj.BuffDatTimeTx = zeros(obj.MIMOAnt,(obj.Nfft+obj.OFDMob.LenCP)*NumSymbols);  % Buffer of Time Data
            obj.BuffDatTimeRx = zeros(obj.MIMOAnt,(obj.Nfft+obj.OFDMob.LenCP)*NumSymbols+obj.MaxImpulse-1); % Buffer of Time Data
            %%%%%%%%%%%%%%%%%%%%%%%%%%
        end
        
        
    end
    
end


