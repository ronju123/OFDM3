function MultAntBinaryMap(obj, xinA, NumAntTxRx, MIMOMethod, SymbPat, zc, zcI, ZM, ZSynch_Data, ZSynchState)
%Alamouti Mapping is below
%Binary to complex mapping is 1st
%NumAntTxRx, MIMOMethod, SymbPat)
%obj.UsedBinIndexSynch=synchI;
obj.M=ZM;
obj.Synch_Data = ZSynch_Data;
obj.SynchState = ZSynchState;

for LoopZ = 1:length(SymbPat)
    xin=xinA(obj.OFDMob.NumBits*obj.NumUsedBins*(LoopZ-1)+1:  ...
             obj.OFDMob.NumBits*obj.NumUsedBins*LoopZ,1);
    xin = [1;0;0;1;0;0;1;0;0;0;1;1;0;0;1;0;0;1;1;0;1;0;0;0];
            %%%%%%%%%%%%%%%%%%%%%%%%%%
        %other MIMO Data Channel Modes
        %%%%%%%%%%%%%%%%%%%%%%%%%%
    if SymbPat(LoopZ)==0  %control
            xin0=zeros(obj.MIMOAnt,length(zc));
            for L=1:obj.MIMOAnt
                xin0(L,:) = zc(obj.SynchState*length(zc)/obj.M(1)+1:(obj.SynchState+1)*length(zc)/obj.M(1));
                obj.SynchState=rem(obj.SynchState+1, obj.M(1));
            end
            obj.BuffDatTx(:,obj.Nfft*(LoopZ-1)+zcI) = xin0;
    elseif SymbPat(LoopZ)==1  %data
        
        switch obj.OFDMob.MappingType
            case 'BPSK'
                %Mapping
                % b0--> -1
                %b1--> +1;
                dataout1=2*xin-1;
            case 'QPSK'
                %obj.NumbBits = 2;
                %streamsize=length(xin)/(obj.NumUsedBins*obj.OFDMob.NumBits);
                streamsize=1;
                tvq = 2.^(obj.OFDMob.NumBits-1:-1:0);
                cdatout = zeros(streamsize*obj.NumUsedBins,1);
                for LoopA = 1:streamsize*obj.NumUsedBins
                    tmpval1 = xin(obj.OFDMob.NumBits*(LoopA-1)+1:obj.OFDMob.NumBits*(LoopA-1)+obj.OFDMob.NumBits,1);
                    %qpskint = sum(tvq.*tmpval1);
                    qpskint = tvq*tmpval1;
                    
                    
                    switch qpskint
                        case 0
                            cdatout(LoopA)=exp(1i * 2*pi/8 * 5);
                        case 1
                            cdatout(LoopA)=exp(1i * 2*pi/8 * 3);
                        case 2
                            cdatout(LoopA)=exp(1i * 2*pi/8 * -1);
                        case 3
                            cdatout(LoopA)=exp(1i * 2*pi/8 * 1);
                    end
                    
                    
                end
        end
        
        if obj.MIMOAnt==1
            xin0=zeros(1,length(cdatout.'));
            xin0(1,:) = cdatout.';
            obj.BuffDatTx(1,obj.Nfft*(LoopZ-1)+obj.UsedBinIndex) = xin0;
            dbg77=1;
        elseif obj.MIMOAnt==2 && strcmp(MIMOMethod, 'STCode')
            %NumAntTxRx, MIMOMethod, SymbPat
            %Mapping for Alamouti Space Time Coding
            xin1 = cdatout.';
            xin0=zeros(2,length(xin1));
            ptrv0=length(xin1)/obj.OFDMob.NumBits+1;
            
            for L=1:streamsize*obj.OFDMob.NumUsedBins/4
                xin0(1, 2*L-1:2*L)=[xin1(2*(L-1)+1)  , -conj(xin1(2*L))];
                xin0(2, 2*L-1:2*L)=[xin1(2*L),    conj(xin1(2*(L-1)+1))];
                xin0(1, ptrv0+2*(L-1):ptrv0+2*L-1)=[xin1(ptrv0+2*(L-1))  , -conj(xin1(ptrv0+2*L-1))  ];
                xin0(2,ptrv0+2*(L-1):ptrv0+2*L-1)=[xin1(ptrv0+2*L-1)    ,  conj(xin1(ptrv0+2*(L-1)))];
            end
            
            %Put the Alamouti 2x2 in a the Data buffer at the used bin indices
            %obj.BuffDatTx = xin0;
            dbg77=1;
            obj.BuffDatTx(:,obj.Nfft*(LoopZ-1)+obj.UsedBinIndex) = xin0;
            
        end

    %%%%%%%%%%%%%%%%%%%%%%%%%%
    %else if SymPath(LoopZ)==2
    %other Channel Modes
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    end
    %obj.BuffDatTx(:,obj.NumUsedBins*(LoopZ-1)+1:obj.NumUsedBins*LoopZ) = xin0;
    %obj.BuffDatTx(:,obj.Nfft*(LoopZ-1)+obj.UsedBinIndexSynch) = xin0;
    dbg77=2;
end
dbg77=1;

end
