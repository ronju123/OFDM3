function MultiAntSymbGen(obj, NSymbs)

for P=1:NSymbs
for m =1:obj.MIMOAnt
tmpv0 = zeros(1,obj.Nfft);
FreqDat = obj.BuffDatTx(m,((P-1)*obj.Nfft+1:P*obj.Nfft));
tmpv1 = ifft(FreqDat, obj.Nfft);
cpdat1 = tmpv1(end-obj.OFDMob.LenCP+1:end); %tail of tmpv1;
TimDat0 = [cpdat1, tmpv1].';
TimDat = TimDat0*sqrt(length(TimDat0)/sum(TimDat0'*TimDat0));
obj.BuffDatTimeTx(m,(P-1)*(obj.Nfft+obj.OFDMob.LenCP)+1:P*(obj.Nfft+obj.OFDMob.LenCP)) = TimDat;
%datain=obj.BuffDatTimeTx(m,:);
%datafreq=(20*log10(abs(fft(datain(obj.OFDMob.LenCP+1:obj.OFDMob.LenCP+obj.Nfft)+1e-14, obj.Nfft)))).';
dbg77=1;
end
dbg77=1;
end
end

