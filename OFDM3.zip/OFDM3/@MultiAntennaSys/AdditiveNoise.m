function AdditiveNoise(varargin)
%                 xaxis='Freq Index';
%                 yaxis='Output in dB';
%                 ztitle='Freq Output of Discrete LTI Channel';
%                 figure(plotnum);
DataFormat='complex';
for k=1:nargin
    switch k
        case 1
            obj        = varargin{1};
        case 2
            SNRType    = varargin{2};
        case 3
            obj.SNRVdB   = varargin{3};
            obj.SNR = 10^(obj.SNRVdB/10);      
        case 4
            channeltype   = varargin{4};
        case 5
            DataFormat = varargin{5};
    end
end
%%%%%%%%%%%%%%%%%%%

sigpow=var(obj.BuffDatTimeTx(1,:));                         % determine the Expected Value of signal power
bitspersymb=length(obj.UsedBinIndex)*obj.OFDMob.NumBits;
samppersymb=obj.Nfft+obj.OFDMob.LenCP;
%Computer the noise variance for the proper EbNo
if strcmp(SNRType, 'Digital')==1 && strcmp(DataFormat, 'Real')==1
    nvar = (1/bitspersymb)*samppersymb*sigpow*10^(-obj.SNRVdB/10);
elseif strcmp(SNRType, 'Analog')==1 && strcmp(DataFormat, 'Real')==1
    nvar = sigpow*10^(-obj.SNRVdB/10);
elseif strcmp(SNRType, 'Digital')==1 && strcmp(DataFormat, 'Complex')==1
    nvar = (1/bitspersymb)*samppersymb*sigpow*10^(-obj.SNRVdB/10)/2;
elseif strcmp(SNRType, 'Analog')==1 && strcmp(DataFormat, 'Complex')==1
    nvar = sigpow*10^(-obj.SNRVdB/10)/2;
end


% Apply AWGN channel;
if strcmp(channeltype, 'FadingPNoise') || strcmp(channeltype, 'AWGN')
    
    for k1=1:obj.MIMOAnt
        TmpVal =0;
        
        for k2=1:obj.MIMOAnt
            TmpVal = TmpVal + obj.BuffDatTimeRx(k2,:);
        end
        
        if strcmp(DataFormat, 'Real')==1
            obj.BuffDatTimeRx(k1,:)= TmpVal + ...
                sqrt(nvar)*randn(size(TmpVal));
            
        elseif strcmp(DataFormat, 'Complex')==1
            obj.BuffDatTimeRx(k1,:)= TmpVal ...
                +  sqrt(nvar)*randn(size(TmpVal))+ ...
                1i*sqrt(nvar)*randn(size(TmpVal));
        end
    end
    
    
    
end
end
            %%%%%%%%%%%%%%%%%%
             
             
 


            