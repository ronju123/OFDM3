function MIMOChanGen(obj, ChanType)

%Time domain channels 
h{1,1}=[0.3977,  0.7954 - 0.3977i,  -0.1988,  0.0994,  -0.0398].';      
h{1,2}=[0.8423i,  0.5391, 0, 0, 0].';    %normalize the channel
h{2,1}=[0.1631,  -0.0815 + 0.9784i,  0.0978, 0, 0].';    
h{2,2}=[0.0572i,  0.3659i, 0.5717 - 0.5717i, 0.4574, 0].';   

for k1=1:obj.MIMOAnt
    for k2=1:obj.MIMOAnt
        if strcmp(ChanType,'AWGN')==1
        obj.ChannelMatTim(k1,k2,1)=1;
        else
        obj.ChannelMatTim(k1,k2,1:length(h{k1,k2}))=h{k1,k2}/norm(h{k1,k2}); 
        end
    end
end

for k1=1:obj.MIMOAnt
    TmpVal =0;
    for k2=1:obj.MIMOAnt
        %reshape(obj.BuffDatTimeTx(k2,:),1,numel(obj.BuffDatTimeTx(k2,:)))
        %reshape(obj.ChannelMatTim(k1,k2,:),1,numel(obj.ChannelMatTim(k1,k2,:)))
        TmpVal = TmpVal + ...
        conv(reshape(obj.BuffDatTimeTx(k2,:),1,numel(obj.BuffDatTimeTx(k2,:))),...
             reshape(obj.ChannelMatTim(k1,k2,:),1,numel(obj.ChannelMatTim(k1,k2,:))));
    end
    obj.BuffDatTimeRx(k1,:)=TmpVal;
end


%Compute the frequency domain channel
for k=1:obj.MIMOAnt
    for a=1:obj.MIMOAnt
        tmp1val=fft(obj.ChannelMatTim(k,a,:), obj.Nfft);
        obj.ChannelMatFreq(k,a,:)=tmp1val;
        
        ddd=reshape(obj.BuffDatTimeRx(1,:),1,numel(obj.BuffDatTimeRx(1,:)));
        dataB = ddd(17:63+17);
        DFreqR=fft(dataB,64);
        
        eee=reshape(obj.BuffDatTimeTx(1,:),1,numel(obj.BuffDatTimeTx(1,:)));
        dataC = eee(17:63+17);
        DFreqT=fft(dataC,64);
        
        HFreq=DFreqR./DFreqT;
        HTim = ifft(HFreq,64);
        dbg77=1;
    end
end
dbg77=1;
end

