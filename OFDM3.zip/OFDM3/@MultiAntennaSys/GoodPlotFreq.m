            function GoodPlotFreq(varargin)
%                 xaxis='Freq Index';
%                 yaxis='Output in dB';
%                 ztitle='Freq Output of Discrete LTI Channel';
%                 figure(plotnum);
             for k=1:nargin
                switch k
                    case 1
                        obj=varargin{1};
                    case 2
                        datain=varargin{2};
                    case 3
                        fs=varargin{3};
                    case 4
                        plotnum=varargin{4};
                    case 5
                        ztitle=varargin{5}.Title;
                        xaxis = varargin{5}.xaxis;
                        yaxis = varargin{5}.yaxis; 
                end
            end
               epsnvec=sqrt(obj.OFDMob.epsvar/2)*randn(size(datain(obj.OFDMob.LenCP+1:obj.OFDMob.LenCP+obj.Nfft)))+...
                       1i*sqrt(obj.OFDMob.epsvar/2)*randn(size(datain(obj.OFDMob.LenCP+1:obj.OFDMob.LenCP+obj.Nfft)));
               datafreq=(20*log10(abs(fft(datain(obj.OFDMob.LenCP+1:obj.OFDMob.LenCP+obj.Nfft)+epsnvec, obj.Nfft)))).';
               xdataval=(0:obj.Nfft-1)*(fs/obj.Nfft);
               xdataval2=xdataval-fs/2;
               datafreq2=[datafreq(obj.Nfft/2+1:end); datafreq(1:obj.Nfft/2)];
               figure(plotnum);
               plot(xdataval2, datafreq2);
                xlabel(xaxis);
                ylabel(yaxis);
                title(ztitle);


            