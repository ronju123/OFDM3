clear all
clc
clf
NUEs = 80;
RatV=0.2;
NenB = round(NUEs*RatV);
CenterCoord = [0,0];
DimX=1000;
DimY=1000;
a = [-1,1; 1,1]^-1*[DimX; 2*CenterCoord(1)];
b = [-1,1; 1,1]^-1*[DimY; 2*CenterCoord(2)];

Density1=NUEs/(DimX*DimY);
lala1=Density1*DimX*DimY;
npoints1 = poissrnd(lala1);
Z1 = rand(npoints1,2);
pprocx1 = a(1)+DimX*Z1(:,1);
pprocy1 = b(1)+DimY*Z1(:,2);
plot(pprocx1, pprocy1, 'b.')


hold on
Density2=NenB/(DimX*DimY);
lala2=Density2*DimX*DimY;
npoints2 = poissrnd(lala2);
Z2 = rand(npoints2,2);
pprocx2 = a(1)+DimX*Z2(:,1);
pprocy2 = b(1)+DimY*Z2(:,2);
figure(1)
plot(pprocx2, pprocy2, 'ro')
