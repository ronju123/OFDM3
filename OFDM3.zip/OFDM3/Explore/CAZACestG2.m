%synchronization channel

clear all
dbstop if error
p=23;
N=64;
M=N-2;
nvar=0.001;
%nvar=0.4;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delf=15e3;  %frequency separation in bins
Ts=1/(N*delf);

ALi=floor(2e-6/Ts);  % range low
AHi=ceil(25e-6/Ts);       % range high
dfr=Ts;  % spatial dimension resolution for search
AL=round(ALi*Ts);
AH=round(AHi*Ts);

rind = randi([ALi AHi],1,1);
r=Ts*rind;

restg=r;
rangerL=ceil((restg-AL)/dfr);
rangerH=ceil((AH-restg)/dfr);
loopvec=[((-rangerL:-1)*dfr+restg),restg,(restg+(1:rangerH)*dfr)];
sumvec=zeros(size(loopvec));
kind=0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
switch rem(M,2) %Zadoff Chu CAZAC sequence
    case 0
        x=exp(-1i*(2*pi/M)*p*((0:M-1).^2)/2);
    case 1
        x=exp(-1i*(2*pi/M)*p*((0:M-1).*(1:M))/2);
end

zobs=x.*exp(-1i*2*pi*delf*restg*[(1:M/2),(-M/2:-1)])+sqrt(nvar)*randn(size(x));

for rest= loopvec %optimum range is in the set
    hold on
    kind=kind+1;
k=0;
g3=zobs.*exp(1i*2*pi*delf*rest*[(1:M/2),(-M/2:-1)]);

for tau=-M/2:M/2
    k=k+1;
xax(k)=tau;
cr(k)=(1/N)*sum(conj(x).*g3([rem(tau+M,M)+1:M,1:rem(tau+M,M)]));
end
sumvec(kind)=real(cr(M/2+1));

if kind==rangerL+1
figure(1)
plot(xax,abs(cr))
xlabel('index')
ylabel('|Correlation|')
titleSTR=strcat({'Cyclic AutoCorrelation of Zadoff Chu: Prime='},{num2str(p)},{', N='},{num2str(N)});
title(titleSTR);
figure(2)
subplot(2,1,1), plot(xax,real(cr));
xlabel('index')
ylabel('Real Correlation')
titleSTR=strcat({'Cyclic AutoCorrelation of Zadoff Chu: Prime='},{num2str(p)},{', N='},{num2str(N)});
subplot(2,1,2), plot(xax,imag(cr));
xlabel('index')
ylabel('Imag Correlation')
titleSTR=strcat({'Cyclic AutoCorrelation of Zadoff Chu: Prime='},{num2str(p)},{', N='},{num2str(N)});
    dbg77=1;
end


figure(3)
plot(loopvec,sumvec,'b')

xlabel('Time (sec)')
ylabel('Lag-0 Delay Estimate')

end
