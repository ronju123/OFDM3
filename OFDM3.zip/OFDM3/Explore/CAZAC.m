%synchronization channel
clear all
dbstop if error
p=47;
N=64;
nvar=0.2;
for n=1:N
g(n)=exp(-1i*(2*pi/N)*p*n^2/2);
end
a=-1+1*1i;
g2=g*a+sqrt(nvar)*randn(size(g));

k=0;
for tau=-N/2:N/2+1
    k=k+1;
xax(k)=tau;
r(k)=(1/N)*sum(conj(g).*g2([rem(tau+N,N)+1:N,1:rem(tau+N,N)]));
end
r2=xcorr(g2,g)
figure(1)
plot(xax,abs(r))
xlabel('index')
ylabel('|Correlation|')
titleSTR=strcat({'Cyclic AutoCorrelation of Zadoff Chu: Prime='},{num2str(p)},{', N='},{num2str(N)});
title(titleSTR);
figure(2)
subplot(2,1,1), plot(xax,real(r));
xlabel('index')
ylabel('Real Correlation')
titleSTR=strcat({'Cyclic AutoCorrelation of Zadoff Chu: Prime='},{num2str(p)},{', N='},{num2str(N)});
subplot(2,1,2), plot(xax,imag(r));
xlabel('index')
ylabel('Imag Correlation')
titleSTR=strcat({'Cyclic AutoCorrelation of Zadoff Chu: Prime='},{num2str(p)},{', N='},{num2str(N)});



