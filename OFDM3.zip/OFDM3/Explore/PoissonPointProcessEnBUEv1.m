clear all
clc
RatV=0.2;
NUEs = 80;
NenB = round(NUEs*RatV);
%Density=0.02;
DimX=100;
DimY=100;
CenterCoord = [0,0];
[a1 ; b1] = [-1,1; 1,2]^-1*[DimX; CenterCoord(1)];
Density1=NUEs/(DimX*DimY);
lala1=Density1*DimX*DimY;
npoints1 = poissrnd(lala1);
pproc1 = -DimX/2+DimX*rand(npoints1, 1);
plot(pproc1(:, 1).*DimX, pproc1(:, 2).*DimY, 'b.')
hold on
Density2=NenB/(DimX*DimY);
lala2=Density2*DimX*DimY;
npoints2 = poissrnd(lala2);
pproc2 = rand(npoints2, 2);
figure(1)
plot(pproc2(:, 1).*DimX, pproc2(:, 2).*DimY, 'ro');